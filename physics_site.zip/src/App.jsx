import PhysicsAstronomySite from "./PhysicsAstronomySite";
export default function App() {
  return <PhysicsAstronomySite />;
}