export default function PhysicsAstronomySite() {
  return (
    <div style={{ padding: 40 }}>
      <h1 style={{ fontSize: 32 }}>Physics & Astronomy Site</h1>
      <p>Silakan ganti file ini dengan versi lengkap dari canvas.</p>
    </div>
  );
}